# WORM ARENA currently uses no custom ProGuard/R8 rules.

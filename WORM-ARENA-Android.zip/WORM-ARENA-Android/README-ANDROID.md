# WORM ARENA — Proyecto Android

Proyecto Android que empaqueta `worm-arena.html` dentro de una WebView nativa.

## Abrir en Android Studio
1. Descomprimí este ZIP.
2. Abrí la carpeta `WORM-ARENA-Android` con Android Studio.
3. Elegí **Open** y seleccioná esa carpeta.
4. Esperá a que Gradle termine de sincronizar y, si Android Studio solicita instalar el SDK 35 o herramientas de compilación, aceptalas.
5. Ejecutá la app en un celular/emulador Android en orientación horizontal.

> El ZIP no incluye el binario `gradle-wrapper.jar` porque el entorno de creación no tiene acceso a Internet para descargarlo. Android Studio puede importar el proyecto y usar su distribución de Gradle; si querés usar `./gradlew` desde una terminal, Android Studio puede generar el wrapper desde **File/Settings > Build Tools > Gradle** o ejecutando `gradle wrapper` con Gradle instalado.

## Generar APK de prueba
En Android Studio: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

## Generar AAB para Google Play
En Android Studio: **Build > Generate Signed App Bundle / APK > Android App Bundle**.
Creá o seleccioná una clave de firma y generá el `.aab` de `release`.

## Identidad
- Nombre: WORM ARENA
- Application ID: `com.wormarena.app`
- Versión inicial: `1.0.0` / `versionCode 1`
- Orientación: horizontal
- Min SDK: 23
- Target SDK: 35

## Incluido
- `worm-arena.html` original dentro de `app/src/main/assets/`
- WebView Android con JavaScript y almacenamiento local habilitados
- Pantalla completa y orientación horizontal
- `manifest.webmanifest`, `icon-192.png` y `sw.js` compatibles con las referencias del HTML
- Icono Android básico de WORM ARENA
